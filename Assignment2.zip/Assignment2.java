import java.util.Scanner;

public class Assignment2
{
  public static void main (String args[])
  {
    // Create a scanner to read from keyboard
    Scanner sc = new Scanner (System.in);

    System.out.println("Enter a line of text to be URL encoded");
    String line = sc.nextLine(); 
    System.out.println("The string read is: " + line);
    System.out.println("Length in chars is: " + line.length());
    String ascii = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.*";
    String encodedLine = "";
    int i;
    for (i = 0; i < line.length(); i++)
    {
      char  ch = line.charAt(i);
      if (ascii.indexOf(ch) >= 0)
      {
        encodedLine += ch;
      } 
      else if (ch == ' ')
      {
        encodedLine += '+';
      }
      else
      {
        String hexValue = Integer.toHexString(ch);
        encodedLine += '%' + hexValue;
      }
    } 
    
    System.out.println("The encoded string: " + encodedLine);
    System.out.println("Length in chars is: " + encodedLine.length());
    
    // Keep console window alive until 'enter' pressed 
    System.out.println();
    System.out.println("Done - press enter key to end program");
    String junk = sc.nextLine();
  }
}