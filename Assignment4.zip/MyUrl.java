package assignment4;

/**
 *
 * @author Melissa
 * MyUrl
 */
        
public class MyUrl
{        
    private String mUrl = ""; // instance variable of a class type - refers to another object
    
    // Constructor
    public MyUrl(String url) {
        if (!url.contains("http://")) {
            mUrl = "http://" + url;
        } else {
            mUrl = url;
        }
    }
   
    // Overloaded Methods
    public void addArgument(String name, String value) {
        String encName = urlEncode(name);
        String encValue = urlEncode(value);
        if (mUrl.contains("?")) {
            mUrl += "&" + encName + "=" + encValue;
        } else {
            mUrl += "?" + encName + "=" + encValue;
            }
        }
            
    public void addArgument(String name, int ivalue) {
        String encName = urlEncode(name);
        String encValue = urlEncode(Integer.toString(ivalue));
        if (mUrl.contains("?")) {
            mUrl += "&" + encName + "=" + encValue;
        } else {
            mUrl += "?" + encName + "=" + encValue;
        }
    }
            
    public void addArgument(String name, double dvalue) {
        String encName = urlEncode(name);
        String encValue = urlEncode(Double.toString(dvalue));
            if (mUrl.contains("?")) {
                mUrl += "&" + encName + "=" + encValue;
            } else {
                mUrl += "?" + encName + "=" + encValue;
            }
        }
    
    // toString Method
    public String toString() {
        return mUrl;
    }
    
    // Static Methods
    public static String urlEncode(String text) {
        String ascii = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.*";
        String result = "";
        int i;
        for (i = 0; i < text.length(); i++)
        {
            char  ch = text.charAt(i);
            if (ascii.indexOf(ch) >= 0) {
                result += ch;
            } else if (ch == ' ') {
                result += '+';
            } else {
                String hexValue = Integer.toHexString(ch);
                result += '%' + hexValue;
            }
        }
        return result;

    }
}