import java.util.Scanner;

public class Assignment1
{
  public static void main (String args[])
  {
    // Create a scanner to read from keyboard
    Scanner sc = new Scanner (System.in);

    System.out.println("Enter a line of text containing the word 'java' somewhere within it.");
    String line = sc.nextLine(); 
    System.out.println("The string read is: " + line);
    System.out.println("Length in chars is: " + line.length());
    System.out.println("All lowercase is: " + line.toLowerCase());
    System.out.println("All uppercase is: " + line.toUpperCase());
    System.out.println("Found 'java' at pos: " + line.indexOf("java"));
    int pos = line.indexOf("java");
    int count = line.length();
    String before = line.substring(0, pos);
    String after = line.substring(pos+4, count);
    String cap = before + "Java" + after;
    System.out.println("Changing to 'Java': " + cap);
    String allcaps = before + "JAVA" + after;
    System.out.println("Changing to 'JAVA': " + allcaps);
    
    // Keep console window alive until 'enter' pressed 
    System.out.println();
    System.out.println("Done - press enter key to end program");
    String junk = sc.nextLine();
  }
}